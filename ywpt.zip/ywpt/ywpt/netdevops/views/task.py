from mycelery.sms.tasks import send_sms2
from mycelery.email.tasks import send_email
from django.shortcuts import render,redirect,HttpResponse
from datetime import timedelta
from datetime import datetime

from ..tasks import add,mul


def task(request):
    # 异步任务
    # send_sms2.delay("110")
    #
    # send_email.delay("109")

    # 定时任务

    # ctime = datetime.now()
    # # 默认用utc时间
    # utc_ctime = datetime.utcfromtimestamp(ctime.timestamp())
    # time_delay = timedelta(seconds=10)
    # task_time = utc_ctime + time_delay
    # res = send_email.apply_async(["911", ], eta=task_time)f
    # print(res.get(timeout=20))

#  执行异步任务；立即执行
    res1 = add.delay(2,2)
    print(res1.get())
    return HttpResponse(res1.id)


# 执行定时任务

    # # 获取本地时间
    # ctime = datetime.now()
    #
    # # 默认用utc时间；将本地时间转化为UTC时间
    # utc_ctime = datetime.utcfromtimestamp(ctime.timestamp())
    #
    # # 定义延时的时间
    # time_delay = timedelta(seconds=10)
    # task_time = utc_ctime + time_delay
    # res2 = mul.apply_async(args=[11,3],eta=task_time)
    # print(res2.id,ctime)
    # return HttpResponse(res2.id)


from celery.result import AsyncResult
from ywpt.celery import app
# from ywpt import celery_app

def get_result(requests):

    nid = requests.GET.get('nid')
    async_result = AsyncResult(id=nid, app=app)

    data = async_result.get()

    return HttpResponse(data)
