from django.shortcuts import render,redirect,HttpResponse
import os

from django import forms





"""文件列表"""
def file(request):

    if request.method == 'GET':
        return render(request,'file.html')

    else:
        file_obj = request.FILES.get('file1')
        f = open(os.path.join('static',file_obj.name),'wb')
        for chunk in file_obj.chunks():
            f.write(chunk)
        f.close()

        return render(request, 'file.html')


import os
from django.http import HttpResponse
from django.views import View


def down(request):

    file_path='/Users/yunhui.han/yunwei/ywpt/netdevops/commd/cisco_cmd.txt'
    with open(file_path,'rb') as file:
        file_data=file.read()

    response = HttpResponse(file_data,content_type='application/octet-stream')
    response['Content-Disposition'] = 'attachment; filename="{}"'.format(os.path.basename(file_path))
    return response





