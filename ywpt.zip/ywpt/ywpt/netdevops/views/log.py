from django.shortcuts import render,redirect
from ..models import Log
from django.utils.safestring import mark_safe
#导入插件
from ..utlis import pagination

def log(request):

    #1.根据用户想要访问的页码，计算出始止位置
    #当前页，默认显示第一页
    page = int(request. GET.get('page',1))
    #定义页码显示多少数据
    page_size = 15
    #定义每页开始位置，例如：第1页；(1 - 1）* 10 = 0
    start = (page - 1) * page_size
    #定义每页结束位置，例如，第1页；1 * 10 = 10     结合开始页，第一页显示的数据为0-10条
    end = page * page_size

    logs = Log.objects.all()[start:end]         #[start:end] 加上这个参数，指定开始页和结束页
    #context = {'logs': logs}


    #计算出总页码
    #数据总条数
    total_count = Log.objects.all().count()
    #python自带divmod计算；总条数 除以 分页显示数量  = 应该显示多少页码；如果有余数，则加1
    total_page_count, div = divmod(total_count,page_size)
    if div:
        total_page_count += 1

    #计算出，显示当前页的前5页和后5页；
    plus = 5

    if total_page_count <= 2 * plus + 1:
        #当数据库中数据量少时，小于11页
        start_page = 1                  #开始页=1
        end_page = total_page_count   #结束也=当前总页码
    else:
        #当前页码<5时
        if page <= plus:
            start_page = 1
            end_page = 2 * plus + 1
        else:
            #当前页码 + 要显示的页码 > 总页码时
            if (page + plus) > total_page_count:
                start_page = total_page_count - 2 * plus
                end_page = total_page_count
            else:
                start_page = page - plus
                end_page = page + plus
    #页码
    #定义一个列表
    page_str_list = []


    #首页
    page_str_list.append('<li><a href="?page={}">首页</a></li>'.format(1))

    #上一页
    if page > 1:
        prev = '<li><a href="?page={}">上一页</a></li>'.format(page - 1)
    else:
        prev = '<li><a href="?page={}">上一页</a></li>'.format(1)
    page_str_list.append(prev)



    #for循环，生成开始页和结束页
    for i in range(start_page, end_page + 1):
        #如果i=当前页，在前端加个样式，如果不等于当前页则不添加
        if i == page:
            ele = '<li class="active"><a href="?page={}">{}</a></li>'.format(i,i)
        else:
            ele = '<li><a href="?page={}">{}</a></li>'.format(i, i)
        #将生成出来的页码写入到列表中
        page_str_list.append(ele)

    #下一页
    if page < total_page_count:
        prev = '<li><a href="?page={}">下一页</a></li>'.format(page + 1)
    else:
        prev = '<li><a href="?page={}">下一页</a></li>'.format(total_page_count)
    page_str_list.append(prev)

    #尾页
    page_str_list.append('<li><a href="?page={}">尾页</a></li>'.format(total_page_count))


    page_string = mark_safe ("".join(page_str_list))

    return render(request, "log.html", {"logs":logs,"page_string":page_string})