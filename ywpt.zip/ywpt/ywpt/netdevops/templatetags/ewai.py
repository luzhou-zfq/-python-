"""
此目录定义django内置函数；
一、必须创建一个templatetags目录
二、在templatetags目录下任意创建一个.py的文件
三、必须定义register = template.Library()
四、使用：在前端界面中{{% load ewai %}}   这个ewai就是创建的.py文件名称
五、{{ data|my_upper }}   |my_upper 调用函数，前面是数据
"""

from django import template

#必须这么定义
register = template.Library()

#必须加这个参数，否则django无法使用此内置函数
@register.filter
def my_upper(value):
    return value.upper()

@register.filter
def my_upper1(value,a):
    return value + a
"""
前端展示：
    name=zhangsan
    <div>
        {{ name|my_upper}}
        {{ name|my_upper1:"123"}}
    </div>
    
    输出：
        ZHANGSAN
        zhangsan123
"""

@register.simple_tag
def my_upper3(value,a,b,c):
    return value + a + b + c
"""
前端展示：
   <div>
        {% my_upper3 "123" "45" "67" "89"%}
   </div>
   输出：123456789
"""



"""
总结：函数 --> 自动执行
simple_filter
    --最多传入两个参数，方式：{{ 第一个参数|函数名称:"第二个参数"}}
    --可以做条件判断
simple_tag
    --无限制，{% 函数名 参数 参数%}
"""