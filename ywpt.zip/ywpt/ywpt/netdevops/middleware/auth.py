from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import HttpResponse,redirect

class AuthMiddleware(MiddlewareMixin):
    def process_request(self,request):

        #1.排除不需要登录就能访问的页面
        #request.path_info 获取当前用户请求的URL;以下的URL是不需要进行登录的
        if request.path_info in ["/login/","/image/code/"]:
            return
        #2.读取当前访问用户的信息，如果能读到 说明已登录
        info_dict =  request.session.get("info")
        if info_dict:
            return

        return redirect("/login/")


