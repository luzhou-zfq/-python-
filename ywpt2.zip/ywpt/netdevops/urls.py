from django.urls import path
from .views import login,check,netdev,inter,backup_config,diff,configure,log,user,login,home,download,data,manage,check,lunxun,task,tas



urlpatterns = [
    path('',login.login,name='login'),

    path('home/',home.home_list,name='home'),
    #设备管理
    path('devices/',netdev.net_dev,name='devices'),
    path('devices/add',netdev.dev_add),
    path('devices/all',netdev.dev_all),
    path('devices/download/',netdev.dev_download),
    #path('upload/from',netdev.upload_form),
    path('devices/<int:nid>/edit/',netdev.dev_edit),
    path('devices/<int:nid>/ssh/',netdev.dev_ssh),



    #接口管理
    path('inter/',inter.interface,name='inter'),

    #配置备份
    path('backup_config/',backup_config.backup,name='backup'),
    #配置下载
    path("backup/download/", backup_config.download,name='backupdown'),
    path("backup/delete/", backup_config.delete),


    #配置对比
    path('diff/',diff.diff_comp,name='diff'),

    #统一配置
    path('configure/',configure.config,name='configure'),

    #任务管理
    path('tasks/',tas.tasks,name='tasks'),
    path('tasks/ajax/',tas.test_ajax),
    path('tasks/add/',tas.task_add),
    path('task/',task.task),
    path('task/result/', task.get_result),

    #日志信息
    path('log/',log.log,name='log'),

    #用户管理
    path('user/',user.user,name='user'),
    path('user/add',user.user_add),
    path('user/<int:nid>/edit/',user.user_edit),

    #登录
    path('login/',login.login,name="login"),


    #注销
    path("logout/",login.logout,name="loginout"),

    #文件下载
    path("download/file1",download.download1,name="dowdload1"),
    path("download/file1",download.download2,name="dowdload2"),

    #数据统计
    path("data/list",data.data_list,name="data"),
    path("data/bar",data.data_bar,),
    path("data/pie",data.data_pie,),
    path("data/kie",data.data_kie,),

    #文件夹管理
    path('file/',manage.file,name="file"),
    path('down/',manage.down,),

    #设备巡检
    path('check/',check.xunjian,name="xj"),
    #轮训
    path('lunxun/1',lunxun.lx1),
    path('lunxun/2',lunxun.lx2),
    path('lunxun/3',lunxun.lx3),
    path('send/msg',lunxun.send_msg),



]



