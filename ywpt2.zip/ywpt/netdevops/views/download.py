from django.shortcuts import render,redirect,HttpResponse

def download1(request):

    return HttpResponse("...")

def download2(request):
        return HttpResponse("...")