from django.shortcuts import render,redirect
from django.http import JsonResponse
from ..models import monitor
from pysnmp.hlapi import *
import datetime
import time

def data_list(request):



    return render(request,"data_list1.html")





"""构造柱状图数据"""
def data_bar(request):

    legend = ["张三","李四"]

    series_list = [
        {
            "name":'张三',
            "type":'bar',
            "data":['10','20','30','60','90','10']
        },
        {
            "name": '李四',
            "type": 'bar',
            "data": ['10','50','70','40','50','100']
        }
    ]

    x_axis = ["09:15:08","09:15:08","09:15:08","09:15:08","09:15:08","09:15:08"]

    result = {
        "status":True,
        "data":{
            "legend":legend,
            "series_list":series_list,
            "x_axis":x_axis,
        }
    }

    return JsonResponse(result)



"""构造饼图"""
def data_pie(request):
    db_data_list=[
        {"value": 1048, "name":'IT部门'},
        {"value": 735, "name":'运营'},
        {"value": 580, "name":'新媒体'},
        {"value": 484, "name":'销售'},

    ]

    result = {
        "status":True,
        "data":db_data_list,
    }
    return JsonResponse(result)




"""定期通过snmp获取设备信息"""

def snmpv2_get(ip, community, oid, port=161):
    errorIndication, errorStatus, errorindex, varBinds = next(
        getCmd(SnmpEngine(),
                CommunityData(community),
                UdpTransportTarget((ip, port)),
                ContextData(),
                ObjectType(ObjectIdentity(oid)),
                )
        )

    # 错误处理
    if errorIndication:
        print(errorIndication)
    elif errorStatus:
        print('%s at %s' % (
            errorStatus.prettyPrint(),
            errorindex and varBinds[int(errorindex) - 1][0] or '?'
        )
                )

    # 如果返回结果有多行，需要拼接后返回
    result = ""
    for varBinds in varBinds:
        result = result + varBinds.prettyPrint()

    # 返回的为一个元组，OID与字符串结果
    return result.split("=")[0].strip(), result.split("=")[1].strip()

def get_info_writedb(ip, rocommunity, seconds):
    while seconds >= 0:

        # CPU 5s 利用率
        cpu_info = snmpv2_get(ip, rocommunity, "1.3.6.1.4.1.2011.6.3.4.1.2.0.4.0", 161)[1]
        # 已用内存
        mem_info = snmpv2_get(ip, rocommunity, "1.3.6.1.4.1.2011.6.3.5.1.1.4.0.4.0", 161)[1]
        # 记录当前时间
        time_info = datetime.datetime.now()
        print(time_info)
        monitor.objects.create(cpu_info=cpu_info,mem_info=mem_info,time=time_info)
        time.sleep(5)
    seconds -= 5

"""构造折线图"""
def data_kie(request):

    #get_info_writedb("10.55.1.200","Shopeebjsnmp",2)

    legend = ["10.55.1.200"]
    obj = monitor.objects.order_by('id')[90:]
    A=[]
    B=[]
    for x in obj:
        A.append(x.cpu_info)
        B.append(str(x.time.hour) + ":" + str(x.time.minute) + ":" + str(x.time.second))

    series_list = [
        {
            "name": '"10.55.1.200"',
            "type": 'line',
            "data": A,
            "smooth": 'true',
        },

    ]

    x_axis = B

    result = {
        "status": True,
        "data": {
            "legend": legend,
            "series_list": series_list,
            "x_axis": x_axis,
        }
    }
    return JsonResponse(result)


    #"""实现静态数据展示"""
    # obj = monitor.objects.order_by('-id')[:10]
    # for x in obj:
    #     print(x.cpu_info)
    #     print(str(x.time.hour)+":"+str(x.time.minute)+":"+str(x.time.second))
    #
    # legend = ["1.200", "1.201"]
    # series_list = [
    #     {
    #         "name": '1.200',
    #         "type": 'line',
    #         "data": ['4', '4', '4', '6', '4', '4','4', '9','4', '5', '8', '6', '10', '4','4', '9'],
    #         "smooth": 'true',
    #     },
    #     {
    #         "name": '1.201',
    #         "type": 'line',
    #         "data": ['5', '5', '5', '5', '5', '3','5', '4','6', '5', '3', '5', '9', '3','11', '4',],
    #         "smooth":'true',
    #     }
    # ]
    #
    # x_axis = ["09:15:08", "09:16:08", "09:17:08", "09:18:08", "09:19:08", "09:20:08","09:21:08","09:22:08","09:23:08", "09:24:08", "09:25:08", "09:25:08", "09:27:08", "09:28:08","09:29:08","09:30:08"]
    #
    # result = {
    #     "status": True,
    #     "data": {
    #         "legend": legend,
    #         "series_list": series_list,
    #         "x_axis": x_axis,
    #     }
    # }
    # return JsonResponse(result)