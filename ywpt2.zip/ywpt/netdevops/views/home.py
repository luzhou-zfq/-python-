from django.shortcuts import render,redirect
from ..models import Device



def home_list(request):


    return  render(request,'home.html')