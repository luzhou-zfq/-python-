from django.shortcuts import render,redirect,HttpResponse
import json

DB=[]

def lx1(request):


    return render(request,'lunxun.html')


def lx2(request):
    return render(request, 'lunxun2.html')


def lx3(request):
    pass


def send_msg(request):
    text = request.GET.get('text')
    DB.append(text)

    return HttpResponse("ok")


