from django.shortcuts import render,redirect

def interface(request):

    return render(request,"inter.html")