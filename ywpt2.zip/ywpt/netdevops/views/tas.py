import json

from django.shortcuts import render,redirect,HttpResponse
from django.views.decorators.csrf import csrf_exempt        #免除post请求需要携带的toten
from django.http import JsonResponse
from ..models import Task
from ..utlis import BootStrapModelForm
from django import forms


class TaskModelFrom(forms.ModelForm):
    class Meta:
        model = Task
        fields = "__all__"

        widgets = {
            "detail":forms.TextInput        #Textarea:生成的标签第多行的输入框
        }

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for name,field in self.fields.items():
            field.widget.attrs = {"class": "form-control"}

def tasks(request):
    form = TaskModelFrom()
    return render(request,"tasks.html",{"form":form,"name":"zhangsan"})



@csrf_exempt
def test_ajax(request):

    data_dict = {"status":True,'data':[11,22,33,44]}
    json_string = json.dump(data_dict)
    return HttpResponse(json_string)
    # return JsonResponse(JsonResponse)


@csrf_exempt
def task_add(request):
    form = TaskModelFrom(data=request.POST)
    if form.is_valid():
        form.save()
        data_dict = {"status": True}
        return HttpResponse(data_dict)

    data_dict = {"status": True,'error':form.errors.ad_json()}
    return HttpResponse(json.dumps(data_dict))





