from pysnmp.hlapi import *


def snmpv2_get(ip,community,oid,port=161):
    errorIndication, errorStatus, errorindex, varBinds = next(
        getCmd(SnmpEngine(),
               CommunityData(community),
               UdpTransportTarget((ip, port)),
               ContextData(),
               ObjectType(ObjectIdentity(oid)),
               )
            )

    #错误处理
    if errorIndication:
        print(errorIndication)
    elif errorStatus:
        print('%s at %s' % (
            errorStatus.prettyPrint(),
            errorindex and varBinds[int(errorindex) - 1][0] or '?'
                )
            )

    # 如果返回结果有多行，需要拼接后返回
    result = ""
    for varBinds in varBinds:
        result = result + varBinds.prettyPrint()

    # 返回的为一个元组，OID与字符串结果
    return  result.split("=")[0].strip(),result.split("=")[1].strip()
