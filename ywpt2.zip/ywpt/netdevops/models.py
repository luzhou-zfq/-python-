from django.db import models
# Create your models here.

"""设备信息管理"""
class Device(models.Model):
    ip_address = models.CharField(max_length=255,verbose_name="管理IP")
    dev_name = models.CharField(max_length=255,verbose_name="设备名称")
    diqu = models.CharField(max_length=255, default="北京",verbose_name="所属地区")
    weizhi = models.CharField(max_length=255,verbose_name="位置")
    xinghao = models.CharField(max_length=255,verbose_name="型号")
    username = models.CharField(max_length=255,verbose_name="用户名")
    password = models.CharField(max_length=255,verbose_name="密码")
    ssh_port = models.IntegerField(default=22,verbose_name="端口")

    #定义选择栏，添加设备时可选择设备类型
    # VENDOR_CHOICES=(
    #     ('huawei','华为'),
    #     ('cisco','思科')
    # )
    #vendor = models.CharField(max_length=255, choices=VENDOR_CHOICES)



"""设备日志管理"""
class Log(models.Model):
    target = models.CharField(max_length=255)
    action = models.CharField(max_length=255)
    status = models.CharField(max_length=255)
    time = models.DateTimeField(null=True)
    messages = models.CharField(max_length=255,blank=True)          #blank=True 表示messages数据可以为空


class backup(models.CharField):
    title=models.CharField(max_length=255,verbose_name="设备名称")
    time=models.DateTimeField(null=True,verbose_name="备份日期")
    ip=models.CharField(null=True,verbose_name="IP地址")

"""用户登录信息管理"""
class Admin(models.Model):
    username = models.CharField(verbose_name="用户名", max_length=64)
    password = models.CharField(verbose_name="密码", max_length=32)

    def __str__(self):
        return self.username


"""任务"""
class Task(models.Model):
    level_choices = (
        (1,"紧急"),
        (2,"重要"),
        (3,"临时")
    )
    level = models.SmallIntegerField(verbose_name="级别",choices=level_choices,default=1)
    title = models.CharField(verbose_name="标题",max_length=256)
    detail = models.TextField(verbose_name="详细信息")
    user = models.ForeignKey(verbose_name="负责人",to="admin",on_delete=models.CASCADE)


"""监控数据"""
class monitor(models.Model):
    cpu_info = models.IntegerField(verbose_name="CPU",)
    mem_info = models.CharField(verbose_name="mem", max_length=64)
    time = models.DateTimeField(null=True)


class monitors(models.Model):

    net_ip = models.CharField(max_length=64,verbose_name="设备IP")
    cpu_info = models.IntegerField(verbose_name="CPU",)
    mem_info = models.CharField(verbose_name="mem", max_length=64)
    tasck = models.CharField(verbose_name="tasck", max_length=64)
    temp = models.CharField(null=True,max_length=64,verbose_name="设备温度")
    time = models.DateTimeField(null=True,verbose_name="时间")

    class Meta:
        verbose_name = '设备状态'
        verbose_name_plural = '设备状态'


"""文件夹"""
class FileRepository(models.Model):
    file_type_choices=(
    (1,"文件"),
    (2,"文件夹"),
    )

    file_type = models.SmallIntegerField(verbose_name="类型",choices=file_type_choices)
    name = models.CharField(verbose_name="文件夹名称",max_length=32,help_text="文件/文件夹名")
    key = models.CharField(verbose_name="文件存储在COS中的KEY",max_length=128,null=True,blank=True)
    file_path = models.CharField(verbose_name='文件路径',max_length=255,null=True,blank=True)
    update_datetime = models.DateTimeField(verbose_name="时间",auto_now=True)


class DevicesBackup(models.Model):
    title=models.CharField(max_length=255,verbose_name="设备名称")
    time=models.DateTimeField(max_length=255,null=True,verbose_name="备份日期")
    ip=models.CharField(null=True,verbose_name="IP地址",max_length=255)
